"use strict";

module.exports = () => [
    "YNA is a tag-language invented by the amazing squaswin.",
    "This bot uses YNA.js to create and execute tags.",
    "YNA Docs: <http://42.rockett.space/yna.html>.",
    "YNA.js Repository: <https://github.com/FelixRilling/ynajs>.",
    "YNA Editor: <https://f-rilling.com/projects/yna_editor/>."
].join("\n");
